TriggerEvent('chat:addSuggestion', '/creatorcode', 'Löse ein Creator-Code ein.', {
    { name="code", help='Beispiel: "ContentCreatorXYZ"' }
})